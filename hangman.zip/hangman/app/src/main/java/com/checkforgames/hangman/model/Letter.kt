package com.checkforgames.hangman.model

data class Letter(val letter: String, val isVisible: Boolean = false)