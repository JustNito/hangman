package com.checkforgames.hangman.utils

enum class GameStatus {
    Game, Win, Loss
}