package com.checkforgames.hangman.model

data class KeyModel(val letter: String, val isPressed: Boolean = false)